import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://bitbucket.org/Mad-Eric/textfiles/raw/master/builds.json'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://bitbucket.org/Mad-Eric/textfiles/raw/master/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
